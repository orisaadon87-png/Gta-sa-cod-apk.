בנייה בלי להתקין כלום:
1. פתח חשבון ב-github.com וצור מאגר חדש.
2. העלה את כל תוכן התיקייה הזו (כולל התיקייה .github).
3. לשונית Actions -> Build APK -> Run workflow.
4. בסיום הורד את apk מתוך Artifacts, חלץ והתקן.

בנייה ב-Android Studio: File -> Open על התיקייה, ואז Build -> Build APK.
