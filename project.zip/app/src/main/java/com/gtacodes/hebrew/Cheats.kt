package com.gtacodes.hebrew

data class Cheat(val name: String, val code: String)

private fun c(n: String, code: String) = Cheat(n, code)

object Cheats {
    val categories: List<Pair<String, List<Cheat>>> = listOf(
        "שחקן ונשקים" to listOf(
            c("סט נשקים 1", "LXGIWYL"),
            c("סט נשקים 2", "KJKSZPJ"),
            c("סט נשקים 3", "UZUMYMW"),
            c("תרמיל סילון", "ROCKETMAN"),
            c("מצנח", "AIYPWZQP"),
            c("מגן אינסופי ובלי טעינת כדורים", "WANRLTW"),
            c("יריות אינסופיות", "FULLCLIP"),
            c("Hitman בכל סוגי הנשקים", "NCSGDAG"),
            c("קארל מוציא ראש מהחלון בנהיגה", "OUIQDMW"),
            c("אפודה + 250,000$ + חיים", "HESOYAM"),
            c("מרוקן את מד החיים", "SZCMAWO"),
            c("חיים ללא הגבלה (לא נשמר)", "BAGUVIX"),
            c("אוויר ללא הגבלה", "CVWKXAM"),
            c("סי'ג'יי קופץ גבוה", "KANGAROO"),
            c("מגה אגרוף", "IAVENJQ"),
            c("קארל לא יהיה רעב", "AEDUWNV")
        ),
        "מדדים" to listOf(
            c("מד נהיגה מלא", "NATURALTALENT"),
            c("מד השמנה מלא", "BTCDBCB"),
            c("ירידה ברמות שרירים ושומן", "KVGYZQK"),
            c("מד שרירים מלא", "JYSDSOD"),
            c("מד כבוד מלא", "OGXSDAG"),
            c("כל מדדי הנשקים מלאים", "VQIMAHA"),
            c("מד סקס אפיל מלא", "EHIBXQS")
        ),
        "משטרה" to listOf(
            c("מעלה מבוקש לשני כוכבים", "OSRBLHH"),
            c("מוריד מבוקש לאפס כוכבים", "ASNAEB"),
            c("מעלה מבוקש לשישה כוכבים", "LJSPQK"),
            c("המשטרה לא מתערבת בשום מצב", "AEZAKMI")
        ),
        "רכבים" to listOf(
            c("טנק", "AIWPRTON"),
            c("מכונית מרוץ 1", "CQZIJMB"),
            c("ג'יפ ראנצ'ר", "JQNTDMH"),
            c("מכונית מרוץ 2", "PDNEJOH"),
            c("מכונית מרוץ 3", "VPJTQWV"),
            c("מכונית בית קברות", "AQTBCODX"),
            c("לימוזינה", "KRIJEBR"),
            c("משאית זבל", "UBHYZHQ"),
            c("קדילק", "RZHSUEW"),
            c("מטוס קרב", "JUMPJET"),
            c("רכב אמפיבי (מים ויבשה)", "KGGGDKP"),
            c("מסוק קרב", "OHDUDE"),
            c("טרקטורון", "AKJJYGLC"),
            c("משאית דלק ענקית", "AMOMHRER"),
            c("טרקטור גדול", "EEGCYXT"),
            c("מטוס סטאנט", "URKQSRK"),
            c("מפלצת שטח", "AGBDLCID")
        ),
        "נהיגה" to listOf(
            c("כל המכוניות מתפוצצות", "CPKTNWT"),
            c("שליטה טובה יותר באופניים", "CJPHONEHOME"),
            c("כל המכוניות בלתי נראות", "XICWMD"),
            c("שליטה טובה יותר ברכב", "PGGOMOY"),
            c("כל הרמזורים ירוקים", "ZEIIVG"),
            c("כל הנהגים אגרסיביים", "YLTEICZ"),
            c("כל הרכבים ורודים", "LLQPFBN"),
            c("כל הרכבים שחורים", "IOWDLAC"),
            c("סירות מעופפות", "AFSNMSMW"),
            c("תנועה של מכוניות פשוטות בלבד", "BGKGTJH"),
            c("תנועה של מכוניות ספורט בלבד", "GUSNHDE"),
            c("מכוניות מעופפות", "RIPAZHA"),
            c("קפיצות אופניים גבוהות", "JHJOECW"),
            c("רכב שמתנגש ברכב שלך מתפוצץ", "JCNRUAD"),
            c("לכל המכוניות יש ניטרו", "COXEFGU"),
            c("מכוניות עפות בהתנגשות", "BSXSGGC"),
            c("עיר נטושה", "THGLOJ"),
            c("כל העיר הופכת לעיירה", "FVTMNBZ"),
            c("למוניות יש ניטרו", "VKYPQCF")
        ),
        "אנשים" to listOf(
            c("כולם נלחמים זה בזה", "AJLOJYQY"),
            c("יש פרס על הראש שלך", "BAGOWPG"),
            c("בכל העיר יש רק כנופיות", "MROEMZH"),
            c("כנופיות שולטות ברחובות", "BIFBUZZ"),
            c("כולם חמושים", "FOOOXFT"),
            c("אלביס בכל מקום", "ASBHGRB"),
            c("אנשים תוקפים אותך", "BGLUAWML"),
            c("העיר הופכת למסיבת חוף", "CIKGCGX"),
            c("נינג'ות בעיר", "AFPHULTL"),
            c("מגנט בנות", "BEKKNQV"),
            c("מצב התפרעות", "IOJUFZN"),
            c("העיר הופכת למסעדה", "PRIEBJ"),
            c("לכולם יש רובה MM9", "SJMAHPE"),
            c("לכולם יש בזוקות", "ZSOXFSQ"),
            c("רכבים ואנשי כפר", "BMTPWHR")
        ),
        "מזג אוויר וזמן" to listOf(
            c("מזג אוויר בהיר", "AFZLLQLL"),
            c("מזג אוויר קיצי", "ICIKPYH"),
            c("מזג אוויר קודר", "ALNSFMZO"),
            c("מזג אוויר גשום", "AUIFRVQS"),
            c("מזג אוויר מעורפל", "CFVFGMJ"),
            c("סופת רעמים", "MGHXYRM"),
            c("סופת חול", "CWJXUOC"),
            c("הזמן עובר מעט מהר יותר", "SPEEDITUP"),
            c("הזמן עובר הרבה יותר מהר", "YSOHNUL"),
            c("משחק מהיר", "PPGWJHT"),
            c("משחק איטי", "LIYOAAY"),
            c("משחק בהילוך איטי", "MUNASEF"),
            c("השעה 00:00 לנצח", "XJVSNAJ"),
            c("השעה 21:00 לנצח", "OFVIAC")
        )
    )
}
