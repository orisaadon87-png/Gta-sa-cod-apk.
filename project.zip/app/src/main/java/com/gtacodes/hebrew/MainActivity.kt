package com.gtacodes.hebrew

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "קודים ל-GTA San Andreas\n\n1. אשר הצגה מעל אפליקציות.\n2. הפעל את הכפתור הצף.\n3. פתח את המשחק ולחץ על הכפתור הכחול \"GTA\".\n\nהקלדה אוטומטית עובדת עם Shizuku (או root). בלי זה הקוד רק מועתק ללוח."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "1. אפשר הצגה מעל אפליקציות"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "2. הפעל כפתור צף"
            setOnClickListener { startOverlay() }
        })
        root.addView(Button(this).apply {
            text = "3. חבר Shizuku"
            setOnClickListener { connectShizuku() }
        })
        root.addView(Button(this).apply {
            text = "עצור"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "קודם אשר הצגה מעל אפליקציות", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku לא פועלת. פתח אותה ולחץ Start")
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("מחובר ✔")
            } else {
                Shizuku.requestPermission(1)
            }
        } catch (e: Throwable) {
            toast("Shizuku לא מותקנת או לא פועלת")
        }
    }
}
