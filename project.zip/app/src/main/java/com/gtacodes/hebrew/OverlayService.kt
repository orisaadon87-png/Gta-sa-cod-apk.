package com.gtacodes.hebrew

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var method = 1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addBubble()
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cheats", "Cheats", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cheats")
            .setContentTitle("קודים ל-GTA SA פעיל")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(x: Int, y: Int, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun addBubble() {
        val b = TextView(this).apply {
            text = "GTA"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1E88E5.toInt())
            }
        }
        val p = params(dp(8), dp(200), dp(56), dp(56))
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    p.x = startX + dx
                    p.y = startY + dy
                    wm.updateViewLayout(v, p)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, p)
        bubble = b
    }

    private fun togglePanel() {
        val existing = panel
        if (existing != null) {
            wm.removeView(existing)
            panel = null
            return
        }
        val v = buildPanel()
        wm.addView(v, params(dp(72), dp(100), dp(300), dp(440)))
        panel = v
    }

    private fun buildPanel(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xF0202124.toInt())
            }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = "קודי GTA SA"
            setTextColor(Color.WHITE)
            textSize = 16f
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(this).apply {
            text = "שיטה $method"
            setOnClickListener {
                method = method % 3 + 1
                text = "שיטה $method"
            }
        })
        header.addView(Button(this).apply {
            text = "כבה"
            setOnClickListener { stopSelf() }
        })
        root.addView(header)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun show(idx: Int) {
            list.removeAllViews()
            for (cheat in Cheats.categories[idx].second) {
                list.addView(Button(this@OverlayService).apply {
                    text = cheat.name
                    isAllCaps = false
                    setOnClickListener { send(cheat) }
                })
            }
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Cheats.categories.forEachIndexed { i, pair ->
            tabs.addView(Button(this).apply {
                text = pair.first
                isAllCaps = false
                setOnClickListener { show(i) }
            })
        }
        root.addView(HorizontalScrollView(this).apply { addView(tabs) })
        root.addView(
            ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        show(0)
        return root
    }

    private fun keyCommand(code: String, m: Int): String {
        val up = code.uppercase()
        if (m == 2) return "input text $up"
        val keys = up.map { ch ->
            when (ch) {
                in 'A'..'Z' -> 29 + (ch - 'A')
                in '0'..'9' -> 7 + (ch - '0')
                else -> 62
            }
        }
        return if (m == 1) {
            keys.joinToString("; sleep 0.12; ") { k ->
                "(input keyevent --duration 100 $k || input keyevent $k)"
            }
        } else {
            keys.joinToString("; sleep 0.08; ") { k -> "input keyevent $k" }
        }
    }

    private fun send(cheat: Cheat) {
        Thread {
            val m = method
            val cmd = keyCommand(cheat.code, m)
            var how: String? = null
            if (ShizukuInput.ready() && ShizukuInput.run(arrayOf("sh", "-c", cmd))) {
                how = "Shizuku"
            } else {
                val rootOk = try {
                    Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
                } catch (e: Exception) {
                    false
                }
                if (rootOk) how = "root"
            }
            Handler(Looper.getMainLooper()).post {
                if (how != null) {
                    toast("נשלח (שיטה $m): ${cheat.name}")
                } else {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("cheat", cheat.code))
                    toast("${cheat.code}  (הועתק. חבר את Shizuku להקלדה אוטומטית)")
                }
            }
        }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
