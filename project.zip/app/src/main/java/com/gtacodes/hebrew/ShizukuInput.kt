package com.gtacodes.hebrew

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuInput {
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun run(cmd: Array<String>): Boolean = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, cmd, null, null) as Process
        p.waitFor() == 0
    } catch (e: Throwable) {
        false
    }
}
